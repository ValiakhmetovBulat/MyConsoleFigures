﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace WindowsFormsApp3
{
    public class Operand
    {
        public object value;
        public Operand(object NewValue)
        {
            this.value = NewValue;
        }
    }
}
